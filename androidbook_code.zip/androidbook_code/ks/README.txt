signingConfigs {
    config {
        keyAlias 'Android'
        keyPassword 'androidbook'
        storeFile file('../../../ks/androidbook.jks')
        storePassword 'androidbook'
    }
}
