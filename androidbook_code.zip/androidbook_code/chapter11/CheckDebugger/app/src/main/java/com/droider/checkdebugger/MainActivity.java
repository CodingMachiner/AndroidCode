/**
 *
 * LICENSE: GNU Affero General Public License, version 3 (AGPLv3)
 * Copyright 2016 - 2017 fei_cong@hotmail.com 67541967@qq.com
 *
 * This file is part of androidbook.
 *   https://github.com/feicong/androidbook
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package com.droider.checkdebugger;

import android.content.pm.ApplicationInfo;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;

import java.net.InetAddress;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {
    TextView tv;
    boolean portused = false;
    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    private boolean isDebuggerConnected() {
        if ((getApplicationInfo().flags &=
                ApplicationInfo.FLAG_DEBUGGABLE) != 0){
            //Log.e("com.droider.antidebug", "程序被修改为可调试状态");
            //android.os.Process.killProcess(android.os.Process.myPid());
            return true;
        }
        return android.os.Debug.isDebuggerConnected();
    }

    private void checkPort(int port) {
        final int port_ = port;
        new Thread() {
            @Override
            public void run() {
                try {
                    InetAddress addr = InetAddress.getByName("127.0.0.1");
                    Socket sock = new Socket(addr, port_);
                    portused = true;
                } catch (Exception e) {
                    e.printStackTrace();
                    portused = false;
                }

                try {
                    runOnUiThread(new Runnable() {

                        @Override
                        public void run() {
                            tv.setText(portused ? "YES" : "NO");
                        }
                    });
                    Thread.sleep(300);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }.start();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "androidbook sample.", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        // Example of a call to a native method
        tv = (TextView) findViewById(R.id.sample_text);

        Button checkdbg_btn = (Button) findViewById(R.id.checkdbg);
        checkdbg_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv.setText(isDebuggerConnected() ? "YES" : "NO");
            }
        });

        Button checkport_btn = (Button) findViewById(R.id.checkport);
        checkport_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //tv.setText(checkPort(23946) ? "YES" : "NO");
                checkPort(23946);
            }
        });

        Button checkstatus_btn = (Button) findViewById(R.id.checkstatus);
        checkstatus_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv.setText(checkStatus() ? "YES" : "NO");
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public native boolean checkStatus();
}
