/**
 *
 * LICENSE: GNU Affero General Public License, version 3 (AGPLv3)
 * Copyright 2016 - 2017 fei_cong@hotmail.com 67541967@qq.com
 *
 * This file is part of androidbook.
 *   https://github.com/feicong/androidbook
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package com.droider.circulate;

import android.os.Bundle;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.ActivityManager.RunningServiceInfo;
import android.app.ActivityManager.RunningTaskInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.view.Menu;
import android.widget.Toast;

import java.util.Iterator;
import java.util.List;

public class MainActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        iterator();     //迭代器循环
        forCirculate(); //for循环
        whileCirculate();  //while循环
        dowhileCirculate(); //do while循环
    }

    /**
     * 获取正在运行的进程列表
     */
    private void iterator() {
        ActivityManager activityManager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        List<RunningAppProcessInfo> psInfos = activityManager.getRunningAppProcesses();
        StringBuilder sb = new StringBuilder();
        for (RunningAppProcessInfo info : psInfos) {
            sb.append(info.processName + '\n');
        }
        Toast.makeText(MainActivity.this, sb.toString(), Toast.LENGTH_SHORT).show();
    }

    /**
     * 获取已安装的程序
     */
    private void forCirculate() {
        PackageManager pm = getApplicationContext().getPackageManager();
        List<ApplicationInfo> appInfos = pm.getInstalledApplications(
                PackageManager.GET_UNINSTALLED_PACKAGES);
        int size = appInfos.size();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < size; i++) {
            ApplicationInfo info = appInfos.get(i);
            sb.append(info.packageName + '\n');
        }
        Toast.makeText(MainActivity.this, sb.toString(), Toast.LENGTH_SHORT).show();
    }

    /**
     * 获取正在运行的任务列表
     */
    private void whileCirculate() {
        ActivityManager activityManager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        List<RunningTaskInfo> taskInfos = activityManager.getRunningTasks(100);
        StringBuilder sb = new StringBuilder();
        Iterator<RunningTaskInfo> iterator = taskInfos.iterator();
        while (iterator.hasNext()) {
            RunningTaskInfo info = iterator.next();
            sb.append(info.toString() + '\n');
        }
        Toast.makeText(MainActivity.this, sb.toString(), Toast.LENGTH_SHORT).show();
    }

    /**
     * 获取正在动迁的服务列表
     */
    private void dowhileCirculate() {
        ActivityManager activityManager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        List<RunningServiceInfo> serviceInfos = activityManager.getRunningServices(100);
        StringBuilder sb = new StringBuilder();
        Iterator<RunningServiceInfo> iterator = serviceInfos.iterator();
        do {
            RunningServiceInfo info = iterator.next();
            sb.append(info.toString() + '\n');
        } while (iterator.hasNext());
        Toast.makeText(MainActivity.this, sb.toString(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }


}
