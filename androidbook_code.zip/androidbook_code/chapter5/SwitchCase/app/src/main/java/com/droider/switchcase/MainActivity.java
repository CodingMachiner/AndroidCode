/**
 *
 * LICENSE: GNU Affero General Public License, version 3 (AGPLv3)
 * Copyright 2016 - 2017 fei_cong@hotmail.com 67541967@qq.com
 *
 * This file is part of androidbook.
 *   https://github.com/feicong/androidbook
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package com.droider.switchcase;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.widget.Toast;

public class MainActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String str1 = packedSwitch(1);
        Toast.makeText(MainActivity.this, str1, Toast.LENGTH_SHORT).show();
        String str2 = sparseSwitch(35);
        Toast.makeText(MainActivity.this, str2, Toast.LENGTH_SHORT).show();
    }
    
    private String packedSwitch(int i) {
        String str = null;
        switch (i) {
            case 0:
                str = "she is a baby";
                break;
            case 1:
                str = "she is a girl";
                break;
            case 2:
                str = "she is a woman";
                break;
            case 3:
                str = "she is an obasan";
                break;
            default:
                str = "she is a person";
                break;
        }
        return str;
    }
    
    private String sparseSwitch(int age) {
        String str = null;
        switch (age) {
            case 5:
                str = "he is a baby";
                break;
            case 15:
                str = "he is a student";
                break;
            case 35:
                str = "he is a father";
                break;
            case 65:
                str = "he is a grandpa";
                break;
            default:
                str = "he is a person";
                break;
        }
        return str;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }

    
}
