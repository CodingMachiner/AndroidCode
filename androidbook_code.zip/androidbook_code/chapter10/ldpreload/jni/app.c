/**
 *
 * LICENSE: GNU Affero General Public License, version 3 (AGPLv3)
 * Copyright 2016 - 2017 fei_cong@hotmail.com 67541967@qq.com
 *
 * This file is part of androidbook.
 *   https://github.com/feicong/androidbook
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

/* app.c */
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

bool checkSN(const char* sn) {
    char realcode[] = "ilikeandroid";
    return !(strcmp(realcode, sn));
}

int main(int argc, char **argv) {
    if (argc != 2) {
        printf("usage: app sn\n");
        return 0;
    }

    if (!checkSN(argv[1])) {
        printf("the sn was invalid!\n");
        return 0;
    }

    printf("thank you for your registration!\n");
    return 0;
}