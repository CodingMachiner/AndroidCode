/**
 *
 * LICENSE: GNU Affero General Public License, version 3 (AGPLv3)
 * Copyright 2016 - 2017 fei_cong@hotmail.com 67541967@qq.com
 *
 * This file is part of androidbook.
 *   https://github.com/feicong/androidbook
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

/*hook.c*/
#include <stdio.h>
#include <dlfcn.h>

void* getrealaddr() {
    void* lib = dlopen("libc.so", RTLD_NOW | RTLD_GLOBAL);
    if (lib == NULL) {
        fprintf(stderr, "could not open file with dlopen() !!: %s\n", dlerror());
        return 0;
    }

    void* symbol = dlsym(lib, "strcmp");
    //fprintf(stdout, "the real strcmp address: 0x%8x\n", symbol);
    dlclose(lib);

    return symbol;
}

int (*src_strcmp)(const char *s1, const char *s2);

int strcmp(const char* s1, const char* s2) {
    //fprintf(stdout, "strcmp called. first arg is: %s, second arg is:%s\n", s1, s2);
    src_strcmp = (int (*)(const char *, const char *))getrealaddr();
    //fprintf(stdout, "src_strcmp address: 0x%8x\n", src_strcmp);
    if ((0 == src_strcmp("123", s1)) || (0 == src_strcmp("123", s2)))  {
        return 0;
    }
    return src_strcmp(s1, s2);
}