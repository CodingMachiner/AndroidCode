setImmediate(function() {
    console.log("[*] Starting script");
    Java.perform(function() {
      clz = Java.use("com.droider.crackme0201.MainActivity");
      clz.checkSN.implementation = function(s1, s2) {
         console.log("[*] checkSN() called");
         console.log("[*] s1: " + s1);
         console.log("[*] s2: " + s2);
         return true;
      };
      console.log("[*] checkSN handler modified");
    });
});