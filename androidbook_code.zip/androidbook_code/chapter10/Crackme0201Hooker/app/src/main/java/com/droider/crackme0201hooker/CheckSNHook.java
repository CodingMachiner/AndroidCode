/**
 *
 * LICENSE: GNU Affero General Public License, version 3 (AGPLv3)
 * Copyright 2016 - 2017 fei_cong@hotmail.com 67541967@qq.com
 *
 * This file is part of androidbook.
 *   https://github.com/feicong/androidbook
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

package com.droider.crackme0201hooker;

import android.content.Context;
import android.util.Log;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

public class CheckSNHook {
    static final String TAG = "Crackme0201Hooker";
    final XC_MethodReplacement replacementTrue = XC_MethodReplacement.returnConstant(true);

    public CheckSNHook(ClassLoader cl) {
        super();

        XposedBridge.log("hooking checkSN.");
        try {
            Class clz = (Class<?>) XposedHelpers.findClass("com.droider.crackme0201.MainActivity", cl);
            XposedBridge.hookAllMethods(clz, "checkSN", replacementTrue);
            /*
            XposedHelpers.findAndHookMethod(clz,
                    "checkSN",
                    String.class, String.class,
                    new XC_MethodHook() {

                        @Override
                        protected void afterHookedMethod(MethodHookParam param)
                                throws Throwable {
                            XposedBridge.log("CheckSN afterHookedMethod called.");
                            String s1 = (String) param.args[0];
                            String s2 = (String) param.args[1];

                            Log.d(TAG, "s1:" + s1);
                            Log.d(TAG, "s2:" + s2);
                            param.setResult(true);

                            super.afterHookedMethod(param);
                        }
                    });
            */
        } catch (Exception e) {
            e.printStackTrace();
        }
        XposedBridge.log("hook checkSN done.");
    }
}
