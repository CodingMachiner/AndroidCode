/**
 *
 * LICENSE: GNU Affero General Public License, version 3 (AGPLv3)
 * Copyright 2016 - 2017 fei_cong@hotmail.com 67541967@qq.com
 *
 * This file is part of androidbook.
 *   https://github.com/feicong/androidbook
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include <stdio.h>

int nums[5] = {1, 2, 3, 4, 5};
int for1(int n) {
    int i = 0;
    int s = 0;
    for (i = 0; i < n; i++) {
        s += i * 2;
    }
    return s;
}
int for2(int n) {
    int i = 0;
    int s = 0;
    for (i = 0; i < n; i++) {
        s += i * i + nums[n - 1];
    }
    return s;
}

int dowhile(int n) {
    int i = 1;
    int s = 0;
    do {
        s += i;
    } while (i++ < n);
    return s;
}
int whiledo(int n) {
    int i = 1;
    int s = 0;
    while (i <= n) {
        s += i++;
    }
    return s;
}

void if1(int n) {
    if (n < 10) {
        printf("the number less than 10\n");
    } else {
        printf("the number greater than or equal to 10\n");
    }
}

void if2(int n) {
    if (n < 16) {
        printf("he is a boy\n");
    } else if (n < 30) {
        printf("he is a young man\n");
    } else if (n < 45) {
        printf("he is a strong man\n");
    } else {
        printf("he is an old man\n");
    }
}

int switch1(int a, int b, int i) {
    switch (i) {
    case 1:
        return a + b;
        break;
    case 2:
        return a - b;
        break;
    case 3:
        return a * b;
        break;
    case 4:
        return a / b;
        break;
    default:
        return a + b;
        break;
    }
}

int main(int argc, char *argv[]) {
    printf("for1:%d\n", for1(5));
    printf("for2:%d\n", for2(5));

    printf("dowhile:%d\n", dowhile(100));
    printf("while:%d\n", whiledo(100));

    if1(5);
    if2(35);

    printf("switch1:%d\n", switch1(3, 5, 3));

    return 0;
}