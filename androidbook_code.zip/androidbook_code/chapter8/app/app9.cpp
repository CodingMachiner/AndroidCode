/**
 *
 * LICENSE: GNU Affero General Public License, version 3 (AGPLv3)
 * Copyright 2016 - 2017 fei_cong@hotmail.com 67541967@qq.com
 *
 * This file is part of androidbook.
 *   https://github.com/feicong/androidbook
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include <iostream>
#include <string>
#include <typeinfo>

class Person {
public:
    Person() {
        age = 31;
        printf("Person:Person() called\n");
    };
    virtual ~Person() {
        printf("Person:~Person() called\n");
    }
    virtual int getAge() {
        return age;
    }
    virtual void setAge(int age_) {
        age = age_;
    }

private:
    int age;
};

class Student : public Person {
public:
    Student() {
        printf("Student:Student() called\n");
    };
    virtual ~Student() {
        printf("Student:~Student() called\n");
    }
    virtual int getAge() {
        printf("Student:~getAge() called\n");
        return 18;
    }
    virtual std::string getName() {
        return name;
    }
    virtual void setName(std::string name_) {
        name = name_;
    }

private:
    std::string name;
};

class Employee {
public:
    Employee() {
        salary = 0;
    };
    virtual int getSalary() {
        return salary;
    }
    virtual void setSalary(int salary_) {
        salary = salary_;
    }

private:
    int salary;
};

class CNEmployee : public Employee, public Person {
public:
    CNEmployee() {
        if (getSalary() < 9000) {
            taxrate = 0.25;
        } else if (getSalary() < 35000) {
            taxrate = 0.3;
        } else if (getSalary() < 55000) {
            taxrate = 0.35;
        } else {
            taxrate = 0.45;
        }
    };
    double getTaxRate() {
        return taxrate;
    }

private:
    double taxrate;
};

int main() {
    Person person;
    Student stu;
    stu.setName("feicong");
    CNEmployee employee;
    employee.setAge(20);
    employee.setSalary(20000);
    Person *ptr = &employee;
    Person &ref = stu;

    std::cout << typeid(person).name() << std::endl;
    std::cout << typeid(employee).name() << std::endl;
    std::cout << typeid(ptr).name() << std::endl;
    std::cout << typeid(*ptr).name() << std::endl;
    std::cout << typeid(ref).name() << std::endl;
    std::cout << ref.getAge() << std::endl;
    std::cout << (dynamic_cast<Employee *>(ptr))->getSalary() << std::endl;
    std::cout << (dynamic_cast<CNEmployee *>(ptr))->getTaxRate() << std::endl;
    std::cout << (dynamic_cast<Student *>(&ref))->getName() << std::endl;

    return 0;
}