/**
 *
 * LICENSE: GNU Affero General Public License, version 3 (AGPLv3)
 * Copyright 2016 - 2017 fei_cong@hotmail.com 67541967@qq.com
 *
 * This file is part of androidbook.
 *   https://github.com/feicong/androidbook
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include <iostream>
#include <stdio.h>

class Person {
public:
    Person() {
        age = 31;
        printf("Person:Person() called\n");
    };
    virtual ~Person() {
        printf("Person:~Person() called\n");
    }
    virtual int getAge() {
        return age;
    }
    virtual void setAge(int age_) {
        age = age_;
    }

private:
    int age;
};

class Student : public Person {
public:
    Student() {
        printf("Student:Student() called\n");
    };
    virtual ~Student() {
        printf("Student:~Student() called\n");
    }
    virtual int getAge() {
        printf("Student:~getAge() called\n");
        return 18;
    }
};

int main(int argc, char *argv[]) {
    Person *person = new (Student);
    person->setAge(28);
    person->getAge();
    delete (person);

    return 0;
}