#!/bin/bash

rm -rf obj libs local
ndk-build NDK_PROJECT_PATH=. APP_BUILD_SCRIPT=./jni/Android.mk NDK_OUT=.