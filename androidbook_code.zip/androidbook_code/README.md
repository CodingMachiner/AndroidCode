# androidbook

《Android软件安全权威指南》随书源码

## 配置环境

`Android Studio`版本为2.3。下载地址：

- macOS: [https://dl.google.com/dl/android/studio/install/2.3.2.0/android-studio-ide-162.3934792-mac.dmg
](https://dl.google.com/dl/android/studio/install/2.3.2.0/android-studio-ide-162.3934792-mac.dmg)

- Windows 64: [https://dl.google.com/dl/android/studio/install/2.3.2.0/android-studio-bundle-162.3934792-windows.exe](https://dl.google.com/dl/android/studio/install/2.3.2.0/android-studio-bundle-162.3934792-windows.exe)

- Linux：[https://dl.google.com/dl/android/studio/ide-zips/2.3.2.0/android-studio-ide-162.3934792-linux.zip](https://dl.google.com/dl/android/studio/ide-zips/2.3.2.0/android-studio-ide-162.3934792-linux.zip)


## 编译

一次全部编译：

```
$ buildall.sh
```

单个项目编译：

```
$ cd chapterx/xxx
$ ./gradlew assembleRelease
```

## 授权

本书所有代码使用AGPL V3协议授权。使用时请遵守授权协议。
