/**
 *
 * LICENSE: GNU Affero General Public License, version 3 (AGPLv3)
 * Copyright 2016 - 2017 fei_cong@hotmail.com 67541967@qq.com
 *
 * This file is part of androidbook.
 *   https://github.com/feicong/androidbook
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include <stdio.h>

int add2(int a, int b, int c, int d, int e, int f, int g, int h, int i) {
  return a + b + c + d + e + f + g + h + i;
}

double add_double(double d1, double d2) { return d1 + d2; }

double mul_double(double d1, double d2, double d3, double d4, double d5,
                  double d6) {
  return d1 * d2 * d3 * d4 * d5 * d6;
}

int main(int argc, char *argv[]) {
  printf("add2: %d\n", add2(1, 2, 3, 4, 5, 6, 7, 8, 9));
  printf("add_double: %f\n", add_double(1.0, 2.0));
  printf("mul_double: %f\n", mul_double(1.0, 2.0, 3.0, 4.0, 5.0, 6.0));
  return 0;
}
