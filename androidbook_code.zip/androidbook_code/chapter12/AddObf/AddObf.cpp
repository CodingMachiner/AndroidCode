/**
 *
 * LICENSE: GNU Affero General Public License, version 3 (AGPLv3)
 * Copyright 2016 - 2017 fei_cong@hotmail.com 67541967@qq.com
 *
 * This file is part of androidbook.
 *   https://github.com/feicong/androidbook
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 */

#include "llvm/IR/Function.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/LegacyPassManager.h"
#include "llvm/IR/Constants.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/Transforms/IPO/PassManagerBuilder.h"

using namespace llvm;

namespace {
struct AddObfPass : public FunctionPass {
    static char ID; // Pass identification, replacement for typeid

    AddObfPass() : FunctionPass(ID) {
        llvm::errs() << "AddObfPass init.\n";
    }

    /*
    bool runOnFunction(Function& F) override {
        for (BasicBlock &B : F) {
            for (Instruction &I: B) {
                llvm::errs() << I << "\n";
            }
        }
        return false;
    }
    */

    /*
    bool runOnFunction(Function &F) override {
        Function *tmp = &F;
        for (Function::iterator bb = tmp->begin(); bb != tmp->end(); ++bb) {
            for (BasicBlock::iterator inst = bb->begin(); inst != bb->end(); ++inst) {
                llvm::errs() << *inst << "\n";
            }
        }

        return false;
    }
    */

    bool runOnFunction(Function &F) override {
        Function *tmp = &F;
        for (Function::iterator bb = tmp->begin(); bb != tmp->end(); ++bb) {
            for (BasicBlock::iterator inst = bb->begin(); inst != bb->end(); ++inst) {
                if (inst->isBinaryOp()) {
                    if (inst->getOpcode() == Instruction::Add) {
                        return modAddInst1(cast<BinaryOperator>(inst));
                    }
                }
            }
        }

        return false;
    }

    // x+y == (x|y) + (x&y)
    bool modAddInst1(BinaryOperator *bo) {
        BinaryOperator *op = NULL;
        BinaryOperator *op2 = NULL;

        if (bo->getOpcode() == Instruction::Add) {
            // x | y
            op = BinaryOperator::Create(Instruction::Or, bo->getOperand(0), bo->getOperand(1), "", bo);
            // x & y
            op2 = BinaryOperator::Create(Instruction::And, bo->getOperand(0), bo->getOperand(1), "", bo);
            op = BinaryOperator::Create(Instruction::Add, op, op2, "", bo);

            op->setHasNoSignedWrap(bo->hasNoSignedWrap());
            op->setHasNoUnsignedWrap(bo->hasNoUnsignedWrap());

            bo->replaceAllUsesWith(op);
        }

        return true;
    }

    // x+y == (x^y) + 2(x&y)
    bool modAddInst2(BinaryOperator *bo) {
        BinaryOperator *op = NULL;
        BinaryOperator *op2 = NULL;

        if (bo->getOpcode() == Instruction::Add) {
            // x ^ y
            op = BinaryOperator::Create(Instruction::Xor, bo->getOperand(0), bo->getOperand(1), "", bo);
            // 2(x & y)
            op2 = BinaryOperator::Create(Instruction::And, bo->getOperand(0), bo->getOperand(1), "", bo);
            ConstantInt *co = (ConstantInt *)ConstantInt::get(bo->getType(), 2);
            op2 = BinaryOperator::Create(Instruction::Mul, co, op2, "", bo);
            op = BinaryOperator::Create(Instruction::Add, op, op2, "", bo);

            op->setHasNoSignedWrap(bo->hasNoSignedWrap());
            op->setHasNoUnsignedWrap(bo->hasNoUnsignedWrap());

            bo->replaceAllUsesWith(op);
        }

        return true;
    }

    // x+y == 2(x|y) - (x^y)
    bool modAddInst3(BinaryOperator *bo) {
        BinaryOperator *op = NULL;
        BinaryOperator *op2 = NULL;

        if (bo->getOpcode() == Instruction::Add) {
            // 2(x | y)
            op = BinaryOperator::Create(Instruction::Or, bo->getOperand(0), bo->getOperand(1), "", bo);
            ConstantInt *co = (ConstantInt *)ConstantInt::get(bo->getType(), 2);
            op = BinaryOperator::Create(Instruction::Mul, co, op, "", bo);

            // (x ^ y)
            op2 = BinaryOperator::Create(Instruction::Xor, bo->getOperand(0), bo->getOperand(1), "", bo);
            op = BinaryOperator::Create(Instruction::Sub, op, op2, "", bo);

            op->setHasNoSignedWrap(bo->hasNoSignedWrap());
            op->setHasNoUnsignedWrap(bo->hasNoUnsignedWrap());

            bo->replaceAllUsesWith(op);
        }

        return true;
    }
};
}

char AddObfPass::ID = 0;

// Automatically enable the pass.
// http://adriansampson.net/blog/clangpass.html
static void registerAddObfPass(const PassManagerBuilder &,
                               legacy::PassManagerBase &PM) {
    PM.add(new AddObfPass());
}
static RegisterStandardPasses
RegisterMyPass(PassManagerBuilder::EP_EarlyAsPossible, registerAddObfPass);
